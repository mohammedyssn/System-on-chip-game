/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc. All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/
/*
* helloworld.c: simple test application
*
* This application configures UART 16550 to baud rate 9600.
* PS7 UART (Zynq) is not initialized by this application, since
* bootrom/bsp configures it to baud rate 115200
*
* ------------------------------------------------
* | UART TYPE BAUD RATE |
* ------------------------------------------------
* uartns550 9600
* uartlite Configurable only in HW design
* ps7_uart 115200 (configured by bootrom/bsp)
*/
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "gpio.h"
#include "xparameters.h"
#define s0 0
#define s1 1
#define s2 2
#define s3 3

// Define the platform struct
typedef struct {
    int sprite_number;
    int start_col,start_row;
    int row_size;
    int col_size;
} platform;

// Create a 5x5 2D array of platform structs
platform platforms[5][14] = {
    {
        {3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
        {3, 0, 0, 30, 40},
        {3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
		{3, 0, 0, 30, 40},
        {3, 0, 0, 30, 40}
    },
    {
    		{s1, 0, 0, 1, 40}, //row on top
    		{7, 1, 28, 2, 40}, // down 1 on top
			{s1, 20, 26, 1, 3}, // first step
    		{s1, 39, 0, 13, 1}, // right wall up
			{s1, 0, 0, 30, 1}, //left wall
    		{4, 3, 25, 2, 15}, //house foundation
			{s1, 4, 27, 3, 1},
			{s1, 16, 27, 3, 1},
			{s1, 4, 15, 10, 1},
			{s1, 16, 15, 7, 1},
			{5, 3, 11, 4, 15}, //Roof
			{s1, 20, 26, 1, 3}, //step 2
			{s1, 39, 18, 12, 1}, //right wall down
			{s1, 24, 24, 1, 2} //step 3
    },
    {
        {s2, 26, 27, 28, 10},
        {s2, 15, 31, 32, 10},
		{s2, 10, 0, 10, 20},
		{s2, 20, 0, 10, 4},
		{s2, 15, 31, 32, 10},
		{s2, 10, 0, 10, 20},
		{s2, 20, 0, 10, 4},
        {s2, 3, 35, 36, 4}
    },
	{
			{s2, 26, 27, 28, 10},
			{s2, 15, 31, 32, 10},
			{s2, 10, 0, 10, 20},
			{s2, 20, 0, 10, 4},
			{s2, 15, 31, 32, 10},
			{s2, 10, 0, 10, 20},
			{s2, 20, 0, 10, 4},
			{s2, 3, 35, 36, 4}
	    },
	{
			{s2, 26, 27, 28, 10},
			{s2, 15, 31, 32, 10},
			{s2, 10, 0, 10, 20},
			{s2, 20, 0, 10, 4},
			{s2, 15, 31, 32, 10},
			{s2, 10, 0, 10, 20},
			{s2, 20, 0, 10, 4},
			{s2, 3, 35, 36, 4}
		 }

};

int backtilemap[1200];/* = {
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1,
s1, s1, s1, s1, s1, s1, s1, s1, s1, s1, s1
};*/
int foretilemap[1200] =  {
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0,
		s0, s0, s0, s0, s0, s0, s0, s0, s0, s0, s0
		};

#define red 4 // : std_logic_vector(3 downto 0) := "0100";
#define grn 2 // : std_logic_vector(3 downto 0) := "0010";
#define blu 1 // : std_logic_vector(3 downto 0) := "0001";
#define clr 8 // : std_logic_vector(3 downto 0) := "1000";
#define blk 0 // "0000"
#define cyn 3 // "0011"
#define mag 5 // "0101"
#define yel 6 // "0110"
#define wht 7 // "0111"

int spritemap[] = {
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,red,red,red,red,red,red,blk,
blk,red,red,red,red,red,red,blk,blk,red,red,red,red,red,red,blk,blk,red,red,red,red,red,red,blk,
blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,blk,

grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,
cyn,cyn,cyn,cyn,cyn,cyn,cyn,cyn,

blk,blk,blk,blk,blk,blk,blk,blk,
red,red,red,red,red,red,red,red,
red,red,red,red,red,red,red,red,
blk,blk,blk,blk,blk,blk,blk,blk,
blk,blk,blk,blk,blk,blk,blk,blk,
red,red,red,red,red,red,red,red,
red,red,red,red,red,red,red,red,
blk,blk,blk,blk,blk,blk,blk,blk,

blk,red,blk,blk,blk,blk,red,blk,
red,red,red,red,red,red,red,red,
blk,red,blk,blk,blk,blk,red,blk,
blk,red,blk,blk,blk,blk,red,blk,
blk,red,blk,blk,blk,blk,red,blk,
blk,red,blk,blk,blk,blk,red,blk,
red,red,red,red,red,red,red,red,
blk,red,blk,blk,blk,blk,red,blk,

yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,
yel,yel,yel,yel,yel,yel,yel,yel,

blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,
blu,blu,blu,blu,blu,blu,blu,blu,

clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr, clr,
clr,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn, grn,
grn,
blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu, clr, blu,
clr,
clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr,
clr, clr, clr, red, red, red, red, clr, clr, clr, clr, red, red, red, red, clr, clr
};
int wesprite = 1;
int wefore = 2;
int weback = 4;

//int backtilemap[1200];


int joy;

// function to fill the passed tile map
void draw_platform_variables(int level, platform arr[][8], int tilemap[]){

	int number_of_platforms = sizeof(platforms[0])/sizeof(platforms[0][0]);// calculates the number of platforms in a level
   for (int k = 0; k < number_of_platforms; k++){
	 int starting_row = platforms[level][k].start_row;
	 int starting_col = platforms[level][k].start_col;
	 int number_of_cols = platforms[level][k].col_size;
	 int number_of_rows = platforms[level][k].row_size;

	 for (int i = starting_row; i < starting_row + number_of_rows; i++) {
	        for (int j = starting_col; j <starting_col + number_of_cols; j++) {

                int index = 40*i + j; // from 2d to 1d
	        	tilemap[index] = platforms[level][k].sprite_number;

	        }

	    }

   }
}

// function to move the draw tile maps to the registers to be read by the fpga board
void move_tiles_to_fpga(int spritemap[], int foretilemap[], int backtilemap[]){
		XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, 0); //set we all off
		for (int x=0; x<2048; x++)
		{
			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 1*4 , x); //set address
			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 2*4 , spritemap[x]); //set data

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, wesprite); //write to spritemap

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, 0); //turn off write
		}
		for (int x=0; x<1200; x++)
		{
			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 3*4 , x); //set address
			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 4*4 , foretilemap[x]); //set data

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, wefore); //write to backmap

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, 0); //turn off write
		}
		for (int x=0; x<1200; x++)
		{

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 5*4, x); //set address
			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 6*4 , backtilemap[x]); //set data

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, weback); //write to foremap

			XGpio_WriteReg(XPAR_VGA_IP_0_S00_AXI_BASEADDR, 0, 0); //turn off write
		}
}

int read_controller()
{

	joy = XGpio_ReadReg(XPAR_CONTROLLER_IP_0_S00_AXI_BASEADDR, 0);
	for(int delay = 0; delay < 2000; delay++){}

//joystickbits 7 downto 0
//7=a
//6=b
//5=start
//4=select
//3=up
//2=down
//1=left
//0=right
//XGpio_WriteReg(XPAR_EXLED_0_S00_AXI_BASEADDR, 0, joy);
	return joy;
}


//draw_platform_variables(0, platforms, backtilemap);
//move_tiles_to_fpga(spritemap, foretilemap, backtilemap);

//draw_platform_variables(1, platforms, backtilemap);
//move_tiles_to_fpga(spritemap,foretilemap, backtilemap );

int main()
{

	//int levels = 0;
	draw_platform_variables(0, platforms, backtilemap);
	draw_platform_variables(1, platforms, backtilemap);
	move_tiles_to_fpga(spritemap, foretilemap, backtilemap);

/*while(1){
	int joy = read_controller();
if (joy == 247 && levels < 6){
	levels++;
	draw_platform_variables(levels, platforms, backtilemap);
	move_tiles_to_fpga(spritemap, foretilemap, backtilemap);
}
else if(joy == 223){
	levels = 0;
	draw_platform_variables(levels, platforms, backtilemap);
	move_tiles_to_fpga(spritemap, foretilemap, backtilemap);
}
else{
	levels = 0;
}


	if (levels < 5 && joy == 223){
		// when select is pressed
		draw_platform_variables(levels, platforms, backtilemap);
		move_tiles_to_fpga(spritemap,foretilemap, backtilemap );
        //if (levels == 4) levels = 0;
        //else
        	levels ++ ;
	} else if (joy == 247){
		// when up is pressed
		levels = 0;
		draw_platform_variables(0, platforms, backtilemap);
		move_tiles_to_fpga(spritemap, foretilemap, backtilemap);
	}
}*/


return 0;
}
